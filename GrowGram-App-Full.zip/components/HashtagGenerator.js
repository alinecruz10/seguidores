import React, { useState } from 'react';
import { ScrollView, TextInput, Button, Text } from 'react-native';
import styles from './styles';

const sampleHashtags = {
  moda: ['#lookdodia', '#modafeminina', '#estilo', '#ootd'],
  receita: ['#receita', '#comidacaseira', '#culinaria', '#pratofeito'],
  beleza: ['#beleza', '#skincare', '#makeup', '#dicasdebeleza']
};

export default function HashtagGenerator(){
  const [topic, setTopic] = useState('');
  const [result, setResult] = useState([]);

  function generate(){
    const key = topic.toLowerCase().trim();
    if(!key) return setResult(['Digite um tema para gerar hashtags.']);
    if(sampleHashtags[key]) setResult(sampleHashtags[key]);
    else setResult([`#${key}`, `#${key}brasil`, `#${key}dicas`, `#${key}insta`, `#${key}online`]);
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Gerador de Hashtags</Text>
      <TextInput placeholder="Digite o tema (ex: moda, receita)" value={topic} onChangeText={setTopic} style={styles.input} />
      <Button title="Gerar" onPress={generate} />
      <View style={{ height:10 }} />
      {result.map((h,i)=> <Text key={i} style={styles.card} selectable>{h}</Text>)}
    </ScrollView>
  );
}