import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Button, View } from 'react-native';
import styles from './styles';

export default function ExplodirAlcance(){
  const [topic, setTopic] = useState('');
  const [plan, setPlan] = useState([]);

  function makePlan(){
    if(!topic) return setPlan(['Digite um tema ou palavra-chave para criar um plano.']);
    const p = [
      `Desafio 7 dias: publique 1 post sobre '${topic}' com CTA para comentar.`,
      `Use 3 formatos: carrossel, Reels e Story para reforçar o mesmo tema.`,
      `Crie um gancho no início do Reels (2s) que provoque curiosidade sobre ${topic}.`,
      `Incentive salvamentos: ofereça um checklist gratuito no Link na Bio.`
    ];
    setPlan(p);
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Explodir Alcance</Text>
      <Text style={styles.smallText}>Planos simples para maximizar alcance orgânico.</Text>
      <TextInput placeholder="Tema (ex: maquiagem natural)" value={topic} onChangeText={setTopic} style={styles.input} />
      <Button title="Criar Plano" onPress={makePlan} />
      <View style={{ height:10 }} />
      {plan.map((p,i)=>(<View key={i} style={styles.card}><Text>{p}</Text></View>))}
    </ScrollView>
  );
}