import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: { padding: 20, backgroundColor: '#ffffff', flex: 1 },
  title: { fontSize: 20, fontWeight: '700', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, marginVertical: 10 },
  buttonSpacing: { height: 10 },
  smallText: { fontSize: 12, color: '#666' },
  card: { backgroundColor: '#f9f9f9', padding: 12, borderRadius: 10, marginVertical: 6 }
});