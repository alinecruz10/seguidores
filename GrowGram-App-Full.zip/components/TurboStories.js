import React, { useState } from 'react';
import { ScrollView, Text, Button, TextInput, View } from 'react-native';
import styles from './styles';

const templates = [
  { title: 'Enquete rápida', text: 'Enquete: Você prefere A ou B? (use adesivo de enquete)' },
  { title: 'Pergunta do dia', text: 'O que você mais quer aprender sobre [tema]?' },
  { title: 'Antes e Depois', text: 'Mostre o resultado + CTA: Salve se quiser ver mais!' }
];

export default function TurboStories(){
  const [topic, setTopic] = useState('');
  const [result, setResult] = useState([]);

  function generateTemplates(){
    if(!topic) return setResult(['Digite um tema para adaptar os templates.']);
    setResult(templates.map(t=> `${t.title}: ${t.text.replace('[tema]', topic)}`));
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Turbo Stories</Text>
      <Text style={styles.smallText}>Modelos de Stories prontos para aumentar respostas e enquetes.</Text>
      <TextInput placeholder="Tema (ex: cuidados com a pele)" value={topic} onChangeText={setTopic} style={styles.input} />
      <Button title="Gerar Modelos" onPress={generateTemplates} />
      <View style={{ height:10 }} />
      {result.map((r,i)=>(<View key={i} style={styles.card}><Text>{r}</Text></View>))}
    </ScrollView>
  );
}