import React, { useState } from 'react';
import { ScrollView, TextInput, Button, Text, View } from 'react-native';
import styles from './styles';

export default function PostPronto(){
  const [theme, setTheme] = useState('');
  const [result, setResult] = useState(null);

  function makePost(){
    if(!theme) return setResult({ text: 'Digite o tema do post.' });
    const hashtags = `#${theme.replace(/\s+/g,'')} #dicas #instatips`;
    const caption = `Comece com uma frase curta sobre ${theme}.\\nConte 2-3 linhas com valor.\\nCTA: Salve e compartilhe!`;
    const idea = `Sugestão de foto: close + objeto relacionado a ${theme}.`;
    setResult({ caption, hashtags, idea });
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Post Pronto</Text>
      <Text style={styles.smallText}>Gera legenda, hashtags e ideia de imagem prontos para postar.</Text>
      <TextInput placeholder="Tema (ex: look do dia)" value={theme} onChangeText={setTheme} style={styles.input} />
      <Button title="Gerar Post" onPress={makePost} />
      <View style={{ height:10 }} />
      {result && (
        <View style={styles.card}>
          <Text style={{ fontWeight:'700' }}>Legenda:</Text>
          <Text selectable>{result.caption}</Text>
          <View style={{ height:8 }} />
          <Text style={{ fontWeight:'700' }}>Hashtags:</Text>
          <Text selectable>{result.hashtags}</Text>
          <View style={{ height:8 }} />
          <Text style={{ fontWeight:'700' }}>Ideia de imagem:</Text>
          <Text>{result.idea}</Text>
        </View>
      )}
    </ScrollView>
  );
}