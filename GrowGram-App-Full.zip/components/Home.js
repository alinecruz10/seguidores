import React from 'react';
import { View, Text, Button, ScrollView } from 'react-native';
import styles from './styles';

export default function Home({ navigation }){
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>GrowGram — Ferramentas para crescer no Instagram</Text>

      <Button title="Gerador de Hashtags" onPress={() => navigation.navigate('Hashtags')} />
      <View style={styles.buttonSpacing} />
      <Button title="Engajamento Turbinado" onPress={() => navigation.navigate('Engajamento')} />
      <View style={styles.buttonSpacing} />
      <Button title="Explodir Alcance (estratégias)" onPress={() => navigation.navigate('Explodir')} />
      <View style={styles.buttonSpacing} />
      <Button title="Turbo Stories (modelos)" onPress={() => navigation.navigate('Stories')} />
      <View style={styles.buttonSpacing} />
      <Button title="Post Pronto (gera post completo)" onPress={() => navigation.navigate('PostPronto')} />

      <View style={{ height:20 }} />
    </ScrollView>
  );
}