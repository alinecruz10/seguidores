import React, { useState } from 'react';
import { ScrollView, Text, TextInput, Button, View } from 'react-native';
import styles from './styles';

export default function Engajamento(){
  const [niche, setNiche] = useState('');
  const [tasks, setTasks] = useState([]);

  function generateTasks(){
    if(!niche) return setTasks(['Digite seu nicho (ex: moda, culinária)']);
    const base = [
      `Comente em 5 perfis do seu nicho hoje com feedback real.`,
      `Publique um Story com pergunta aberta sobre ${niche}.`,
      `Faça um Reels com 1 dica rápida sobre ${niche} (15-30s).`,
      `Peça nos posts para salvar e compartilhar — aumente salvamentos.`,
      `Responda a todos os comentários nas próximas 2 horas.`
    ];
    setTasks(base);
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Engajamento Turbinado</Text>
      <Text style={styles.smallText}>Tarefas diárias práticas para aumentar interação real (seguidores verdadeiros).</Text>
      <TextInput placeholder="Digite seu nicho" value={niche} onChangeText={setNiche} style={styles.input} />
      <Button title="Gerar Tarefas" onPress={generateTasks} />
      <View style={{ height:10 }} />
      {tasks.map((t,i)=>(
        <View key={i} style={styles.card}><Text>{t}</Text></View>
      ))}
    </ScrollView>
  );
}