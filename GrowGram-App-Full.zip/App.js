import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './components/Home';
import HashtagGenerator from './components/HashtagGenerator';
import Engajamento from './components/Engajamento';
import ExplodirAlcance from './components/ExplodirAlcance';
import TurboStories from './components/TurboStories';
import PostPronto from './components/PostPronto';

const Stack = createNativeStackNavigator();

export default function App(){
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} options={{ title: 'GrowGram' }} />
        <Stack.Screen name="Hashtags" component={HashtagGenerator} options={{ title: 'Hashtags' }} />
        <Stack.Screen name="Engajamento" component={Engajamento} options={{ title: 'Engajamento Turbinado' }} />
        <Stack.Screen name="Explodir" component={ExplodirAlcance} options={{ title: 'Explodir Alcance' }} />
        <Stack.Screen name="Stories" component={TurboStories} options={{ title: 'Turbo Stories' }} />
        <Stack.Screen name="PostPronto" component={PostPronto} options={{ title: 'Post Pronto' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}