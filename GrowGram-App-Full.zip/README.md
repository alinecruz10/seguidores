# GrowGram - App para crescimento no Instagram (Português)

Este projeto é uma versão funcional com telas para: Hashtags, Engajamento Turbinado, Explodir Alcance, Turbo Stories e Post Pronto.

## Testar
1. Descompacte o ZIP.
2. No terminal: `npm install`
3. `npx expo start`
4. Abra Expo Go e escaneie o QR code.

## Build APK (opção recomendada: EAS Build)
1. `npm install -g eas-cli`
2. `eas build -p android`